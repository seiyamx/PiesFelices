create trigger tg_consultorio_upd
  before UPDATE
  on consultorio
  for each row
  SET NEW.fch_modificacion = UNIX_TIMESTAMP(NOW());

