create trigger tg_categorias_ins
  before INSERT
  on categorias
  for each row
  SET NEW.fch_creacion = UNIX_TIMESTAMP(NOW()), NEW.fch_modificacion = UNIX_TIMESTAMP(NOW());

