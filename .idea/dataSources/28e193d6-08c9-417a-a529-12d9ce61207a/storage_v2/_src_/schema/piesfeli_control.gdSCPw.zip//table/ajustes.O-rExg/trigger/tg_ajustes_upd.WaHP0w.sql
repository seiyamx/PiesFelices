create trigger tg_ajustes_upd
  before UPDATE
  on ajustes
  for each row
  SET NEW.fch_modificacion = UNIX_TIMESTAMP(NOW());

