create trigger tg_ventas_ins
  before INSERT
  on ventas
  for each row
  SET NEW.fch_creacion = UNIX_TIMESTAMP(NOW());

