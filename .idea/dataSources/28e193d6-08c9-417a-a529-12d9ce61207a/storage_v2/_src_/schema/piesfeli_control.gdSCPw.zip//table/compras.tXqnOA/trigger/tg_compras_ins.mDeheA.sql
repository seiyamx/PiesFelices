create trigger tg_compras_ins
  before INSERT
  on compras
  for each row
  SET NEW.fch_creacion = UNIX_TIMESTAMP(NOW());

