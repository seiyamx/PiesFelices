create trigger tg_consultorio_ins
  before INSERT
  on consultorio
  for each row
  SET NEW.fch_creacion = UNIX_TIMESTAMP(NOW());

