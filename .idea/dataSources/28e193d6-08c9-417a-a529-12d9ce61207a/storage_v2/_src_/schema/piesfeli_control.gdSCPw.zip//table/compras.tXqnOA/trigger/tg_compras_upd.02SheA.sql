create trigger tg_compras_upd
  before UPDATE
  on compras
  for each row
  SET NEW.fch_modificacion = UNIX_TIMESTAMP(NOW());

