create trigger tg_productos_upd
  before UPDATE
  on categorias
  for each row
  SET NEW.fch_modificacion = UNIX_TIMESTAMP(NOW());

