create trigger tg_ajustes_detalle_ins
  before INSERT
  on ajustes_detalle
  for each row
  SET NEW.fch_creacion = UNIX_TIMESTAMP(NOW());

