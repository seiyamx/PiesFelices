create trigger tg_ventas_detalle_ins
  before INSERT
  on ventas_detalle
  for each row
  SET NEW.fch_creacion = UNIX_TIMESTAMP(NOW());

