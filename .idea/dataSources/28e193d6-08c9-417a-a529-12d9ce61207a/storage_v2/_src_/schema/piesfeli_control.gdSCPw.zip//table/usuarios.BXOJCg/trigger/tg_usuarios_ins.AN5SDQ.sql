create trigger tg_usuarios_ins
  before INSERT
  on usuarios
  for each row
  SET NEW.fch_creacion = UNIX_TIMESTAMP(NOW());

