create trigger tg_ventas_upd
  before UPDATE
  on ventas
  for each row
  SET NEW.fch_modificacion = UNIX_TIMESTAMP(NOW());

