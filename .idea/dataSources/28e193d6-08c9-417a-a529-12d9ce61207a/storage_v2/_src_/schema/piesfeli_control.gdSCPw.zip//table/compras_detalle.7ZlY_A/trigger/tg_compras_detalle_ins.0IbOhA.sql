create trigger tg_compras_detalle_ins
  before INSERT
  on compras_detalle
  for each row
  SET NEW.fch_creacion = UNIX_TIMESTAMP(NOW());

