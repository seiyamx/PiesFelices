create trigger tg_pagos_ins
  before INSERT
  on pagos
  for each row
  SET NEW.fch_creacion = UNIX_TIMESTAMP(NOW());

